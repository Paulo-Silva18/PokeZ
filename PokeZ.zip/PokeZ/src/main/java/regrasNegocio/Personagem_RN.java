/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regrasNegocio;

import classes_bd.Personagem_BD;
import java.sql.SQLException;
import java.util.List;
import objetos.Movimento;
import objetos.Personagem;
import objetos.Status;
import objetos.Tecnicas;
import objetos.Transformacao;

/**
 *
 * @author Paulo Henrique
 */
public class Personagem_RN {
    Personagem_BD p_BD;
    public Personagem_RN() {
        p_BD = new Personagem_BD();
    }
    public void salvarPersonagem(Personagem p) {
        p_BD.salvar(p);
    }
    
    public void deletarPersonagem(Personagem p) {
        p_BD.deletar(p);
    }
    
    public void atualizarPersonagem(Personagem p) {
        p_BD.atualizar(p);
    }
    
    public void mostrarPersonagens() throws SQLException {
        List<Personagem> lstP = p_BD.getPersonagens_All();
        mostrarPersonagens(lstP);
    }
    
    public void mostrarPersonagens(List<Personagem> personagens) throws SQLException {
        for (Personagem personagem : personagens) {
            System.out.println("ID: " + personagem.getId());
            System.out.println("Nome: " + personagem.getNome());
            System.out.println("Raça: " + personagem.getRaca());
            System.out.println("Altura: " + personagem.getAltura());
            System.out.println("Peso: " + personagem.getPeso());
            mostrarMovimentos(personagem.getMovimentos());
            mostrarStatusS(personagem.getStatus());
            mostrarTecnicas(personagem.getTecnicas());
            mostrarTransformacoes(personagem.getTransformacoes());
            System.out.println("\n");
        }
    }
    
    public void mostrarMovimentos (List<Movimento> movimentos) {
        for (Movimento movimento : movimentos) {
            System.out.println("ID Movimento: " + movimento.getId_movimento());
            System.out.println("Nome do movimento: " + movimento.getNome());
            System.out.println("Dano: " + movimento.getDano());
            System.out.println("PP: " + movimento.getPp());
            System.out.println("Tipo do movimento: " + movimento.getTipo());
            System.out.println("ID Personagem: " + movimento.getPersonagem().getId());
            System.out.println("\n");
        }
    }
    
    public void mostrarStatusS (List<Status> statusS) {
        for (Status status : statusS) {
            System.out.println("ID Status: " + status.getId_status());
            System.out.println("Ataque: " + status.getAtaque());
            System.out.println("Defesa: " + status.getDefesa());
            System.out.println("HP: " + status.getHp());
            System.out.println("Velocidade: " + status.getVelocidade());
            System.out.println("Speed Ataque: " + status.getSpeed_ataque());
            System.out.println("Speed Defesa: " + status.getSpeed_defesa());
            System.out.println("ID Personagem: " + status.getPersonagem().getId());
            System.out.println("\n");
        }
    }
    
    public void mostrarTecnicas (List<Tecnicas> tecnicasS) {
        for (Tecnicas tecnicas : tecnicasS) {
            System.out.println("ID Tecnica: " + tecnicas.getId_tecnica());
            System.out.println("Nome da tecnica: " + tecnicas.getNome());
            System.out.println("Efeito da tecnica: " + tecnicas.getEfeito());
            System.out.println("Tipo da tecnica: " + tecnicas.getTipo());
            System.out.println("ID Personagem: " + tecnicas.getPersonagem().getId());
            System.out.println("\n");
        }
    }
    
    public void mostrarTransformacoes (List<Transformacao> transformacoes) {
        for (Transformacao transformacao : transformacoes) {
            System.out.println("ID Transformacao: " + transformacao.getId_transformacao());
            System.out.println("Nome da transformacao: " + transformacao.getNome());
            System.out.println("Nivel da transformacao: " + transformacao.getNivel());
            System.out.println("ID Personagem: " + transformacao.getPersonagem().getId());
            System.out.println("\n");
        }
    }
}
