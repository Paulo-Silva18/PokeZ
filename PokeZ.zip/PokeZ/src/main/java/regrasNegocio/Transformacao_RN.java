/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regrasNegocio;

import classes_bd.Transformacao_BD;
import java.sql.SQLException;
import java.util.List;
import objetos.Transformacao;

/**
 *
 * @author Paulo Henrique
 */
public class Transformacao_RN {
    Transformacao_BD tr_BD;
    public Transformacao_RN() {
        tr_BD = new Transformacao_BD();
    }
    public void salvarTransformacao(Transformacao tr) {
        tr_BD.salvar(tr);
    }
    
    public void deletarTransformacao(Transformacao tr) {
        tr_BD.deletar(tr);
    }
    
    public void atualizarTransformacao(Transformacao tr) {
        tr_BD.atualizar(tr);
    }
    
    public void mostrarTransformacoes() throws SQLException {
        List<Transformacao> transformacoes = tr_BD.getTransformacoes();
        for (Transformacao transformacao : transformacoes) {
            System.out.println("ID: " + transformacao.getId_transformacao());
            System.out.println("Nome: " + transformacao.getNome());
            System.out.println("Nivel: " + transformacao.getNivel());
            System.out.println("ID Personagem: " + transformacao.getPersonagem().getId());
            System.out.println("\n");
        }
    }
}
