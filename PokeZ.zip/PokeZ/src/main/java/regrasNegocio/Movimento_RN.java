/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regrasNegocio;

import classes_bd.Movimento_BD;
import java.sql.SQLException;
import java.util.List;
import objetos.Movimento;

/**
 *
 * @author Paulo Henrique
 */
public class Movimento_RN {
    Movimento_BD m_BD;
    public Movimento_RN() {
        m_BD = new Movimento_BD();
    }
    public void salvarMovimento(Movimento m) {
        m_BD.salvar(m);
    }
    
    public void deletarMovimento(Movimento m) {
        m_BD.deletar(m);
    }
    
    public void atualizarMovimento(Movimento m) {
        m_BD.atualizar(m);
    }
    
    public void mostrarMovimentos() throws SQLException {
        List<Movimento> movimentos = m_BD.getMovimentos();
//        System.out.println(movimentos.get(0).getPersonagem().toString());
        
        for (Movimento movimento : movimentos) {
            System.out.println("ID: " + movimento.getId_movimento());
            System.out.println("Nome: " + movimento.getNome());
            System.out.println("Dano: " + movimento.getDano());
            System.out.println("PP: " + movimento.getPp());
            System.out.println("Tipo: " + movimento.getTipo());
            System.out.println("ID Personagem: " + movimento.getPersonagem().getId());
            System.out.println("\n");
        }
    }
}
