/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regrasNegocio;

import classes_bd.Status_BD;
import java.sql.SQLException;
import java.util.List;
import objetos.Status;

/**
 *
 * @author Paulo Henrique
 */
public class Status_RN {
    Status_BD s_BD;
    public Status_RN() {
        s_BD = new Status_BD();
    }
    public void salvarStatus(Status s) {
        s_BD.salvar(s);
    }
    
    public void deletarStatus(Status s) {
        s_BD.deletar(s);
    }
    
    public void atualizarStatus(Status s) {
        s_BD.atualizar(s);
    }
    
    public Status buscarStatusPorId(int id) {
        return s_BD.buscarPorId(id);
    }
    
    public void mostrarStatusS() throws SQLException {
        List<Status> statusS = s_BD.getStatusS();
        for (Status status : statusS) {
            System.out.println("ID: " + status.getId_status());
            System.out.println("Ataque: " + status.getAtaque());
            System.out.println("Defesa: " + status.getDefesa());
            System.out.println("HP: " + status.getHp());
            System.out.println("Velocidade: " + status.getVelocidade());
            System.out.println("Speed Ataque: " + status.getSpeed_ataque());
            System.out.println("Speed Defesa: " + status.getSpeed_defesa());
            System.out.println("ID Personagem: " + status.getPersonagem().getId());
            System.out.println("\n");
        }
    }
}
