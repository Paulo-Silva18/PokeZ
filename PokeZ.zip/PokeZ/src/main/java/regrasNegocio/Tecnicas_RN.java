/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regrasNegocio;

import classes_bd.Tecnicas_BD;
import java.sql.SQLException;
import java.util.List;
import objetos.Tecnicas;

/**
 *
 * @author Paulo Henrique
 */
public class Tecnicas_RN {
    Tecnicas_BD t_BD;
    public Tecnicas_RN() {
        t_BD = new Tecnicas_BD();
    }
    public void salvarTecnicas(Tecnicas t) {
        t_BD.salvar(t);
    }
    
    public void deletarTecnicas(Tecnicas t) {
        t_BD.deletar(t);
    }
    
    public void atualizarTecnicas(Tecnicas t) {
        t_BD.atualizar(t);
    }

    public Tecnicas buscarTecnicaPorId(int id) {
        return t_BD.buscarPorId(id);
    }
    
    public void mostrarTecnicasS() throws SQLException {
        List<Tecnicas> tecnicasS = t_BD.getTecnicasS();
        for (Tecnicas tecnica : tecnicasS) {
            System.out.println("ID: " + tecnica.getId_tecnica());
            System.out.println("Nome: " + tecnica.getNome());
            System.out.println("Efeito: " + tecnica.getEfeito());
            System.out.println("Tipo: " + tecnica.getTipo());
            System.out.println("ID Personagem: " + tecnica.getPersonagem().getId());
            System.out.println("\n");
        }
    }
    
}
