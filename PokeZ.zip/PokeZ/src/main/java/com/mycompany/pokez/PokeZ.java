/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pokez;

import classes_menu.Menu_Principal;
import java.sql.SQLException;

/**
 *
 * @author Paulo Henrique
 */
public class PokeZ {

    public static void main(String[] args) throws SQLException {
        Menu_Principal mp = new Menu_Principal();
        mp.menuPrincipal();
    }
}
