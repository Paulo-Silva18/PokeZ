/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

import java.util.List;

/**
 *
 * @author Paulo Henrique
 */
public class Personagem {
    private int id;
    private String nome;
    private String raca;
    private double altura;
    private double peso;
    private List<Transformacao> transformacoes;
    private List<Tecnicas> tecnicas;
    private List<Movimento> movimentos;
    private List<Status> status;
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public List<Transformacao> getTransformacoes() {
        return transformacoes;
    }

    public void setTransformacoes(List<Transformacao> transformacoes) {
        this.transformacoes = transformacoes;
    }

    public List<Tecnicas> getTecnicas() {
        return tecnicas;
    }

    public void setTecnicas(List<Tecnicas> tecnicas) {
        this.tecnicas = tecnicas;
    }

    public List<Movimento> getMovimentos() {
        return movimentos;
    }

    public void setMovimentos(List<Movimento> movimentos) {
        this.movimentos = movimentos;
    }

    public List<Status> getStatus() {
        return status;
    }

    public void setStatus(List<Status> status) {
        this.status = status;
    }
    
    
}
