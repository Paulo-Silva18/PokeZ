/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

/**
 *
 * @author Paulo Henrique
 */
public class Transformacao {
    private int id_transformacao;
    private String nome;
    private int nivel;
    private Personagem personagem;
    

    public int getId_transformacao() {
        return id_transformacao;
    }

    public void setId_transformacao(int id_transformacao) {
        this.id_transformacao = id_transformacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public Personagem getPersonagem() {
        return personagem;
    }

    public void setPersonagem(Personagem personagem) {
        this.personagem = personagem;
    }
    
    
}
