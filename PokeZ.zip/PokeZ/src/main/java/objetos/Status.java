
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

/**
 *
 * @author Paulo Henrique
 */
public class Status {
    private int id_status;
    private int ataque;
    private int defesa;
    private int hp;
    private int velocidade;
    private int speed_ataque;
    private int speed_defesa;
    private Personagem personagem;

    public int getId_status() {
        return id_status;
    }

    public void setId_status(int id_status) {
        this.id_status = id_status;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getDefesa() {
        return defesa;
    }

    public void setDefesa(int defesa) {
        this.defesa = defesa;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    public int getSpeed_ataque() {
        return speed_ataque;
    }

    public void setSpeed_ataque(int speed_ataque) {
        this.speed_ataque = speed_ataque;
    }

    public int getSpeed_defesa() {
        return speed_defesa;
    }

    public void setSpeed_defesa(int speed_defesa) {
        this.speed_defesa = speed_defesa;
    }

    public Personagem getPersonagem() {
        return personagem;
    }

    public void setPersonagem(Personagem personagem) {
        this.personagem = personagem;
    }
    
    
}
