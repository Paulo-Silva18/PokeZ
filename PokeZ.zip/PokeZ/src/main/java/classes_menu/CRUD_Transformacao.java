/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Personagem;
import objetos.Transformacao;
import regrasNegocio.Personagem_RN;
import regrasNegocio.Transformacao_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Transformacao {
    public static void executar(Scanner scanner) throws SQLException {
        Transformacao_RN transformacaoRN = new Transformacao_RN();
        Personagem_RN personagemRN = new Personagem_RN();
        int opcao;
        
        do {
            System.out.println("=== Transformação ===");
            System.out.println("1 - Cadastrar Transformação");
            System.out.println("2 - Excluir Transformação");
            System.out.println("3 - Listar Transformação");
            System.out.println("4 - Atualizar Transformação");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    System.out.println("Digite o ID do Personagem para associar a Transformação: ");
                    int idPersonagem = scanner.nextInt();
                    scanner.nextLine();

                    Personagem p_encontrado = personagemRN.buscarPersonagemPorId(idPersonagem);

                    if (p_encontrado != null) {
                        Transformacao tr = new Transformacao();
                        tr.setPersonagem(p_encontrado);

                        System.out.println("Nome: ");
                        tr.setNome(scanner.nextLine());
                        System.out.println("Nivel: ");
                        tr.setNivel(scanner.nextInt());
                        scanner.nextLine();
                        transformacaoRN.salvarTransformacao(tr);
                        System.out.println("Transformação cadastrada com sucesso!");
                    } else {
                        System.out.println("ERRO: Personagem com ID " + idPersonagem + " não existe. Impossível cadastrar a transformação.");
                    }
                }
                case 2 -> {
                    System.out.println("Digite o ID da Transformação para excluir: ");
                    int idParaExcluir = scanner.nextInt();
                    scanner.nextLine();

                    Transformacao tr_encontrada = transformacaoRN.buscarTransformacaoPorId(idParaExcluir);

                    if (tr_encontrada != null) {
                        transformacaoRN.deletarTransformacao(tr_encontrada);
                        System.out.println("Transformação excluída com sucesso!");
                    } else {
                        System.out.println("ERRO: Transformação com ID " + idParaExcluir + " não encontrada.");
                    }
                }
                case 3 -> transformacaoRN.mostrarTransformacoes();
                case 4 -> {
                    System.out.println("Digite o ID da Transformação para atualizar: ");
                    int idParaAtualizar = scanner.nextInt();
                    scanner.nextLine();

                    Transformacao tr_para_atualizar = transformacaoRN.buscarTransformacaoPorId(idParaAtualizar);

                    if (tr_para_atualizar != null) {
                        System.out.println("Nome: ");
                        tr_para_atualizar.setNome(scanner.nextLine());
                        System.out.println("Nivel: ");
                        tr_para_atualizar.setNivel(scanner.nextInt());
                        transformacaoRN.atualizarTransformacao(tr_para_atualizar);
                        System.out.println("Transformação atualizada com sucesso!");
                    } else {
                        System.out.println("ERRO: Transformação com ID " + idParaAtualizar + " não encontrada.");
                    }
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
    
}
