/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Personagem;
import objetos.Transformacao;
import regrasNegocio.Transformacao_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Transformacao {
    public static void executar(Scanner scanner) throws SQLException {
        Transformacao_RN transformacaoRN = new Transformacao_RN();
        int opcao;
        
        do {
            System.out.println("=== Transformação ===");
            System.out.println("1 - Cadastrar Transformação");
            System.out.println("2 - Excluir Transformação");
            System.out.println("3 - Listar Transformação");
            System.out.println("4 - Atualizar Transformação");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    Transformacao tr = new Transformacao();
                    
                    Personagem p = new Personagem();
                    System.out.println("ID do Personagem: ");
                    p.setId(scanner.nextInt());
                    scanner.nextLine();
                    tr.setPersonagem(p);
                    
                    System.out.println("Nome: ");
                    tr.setNome(scanner.nextLine());
                    System.out.println("Nivel: ");
                    tr.setNivel(scanner.nextInt());
                    scanner.nextLine();
                    transformacaoRN.salvarTransformacao(tr);
                }
                case 2 -> {
                    Transformacao tr = new Transformacao();
                    System.out.println("Digite o ID da Transformação para excluir: ");
                    tr.setId_transformacao(scanner.nextInt());
                    scanner.nextLine();
                    transformacaoRN.deletarTransformacao(tr);
                }
                case 3 -> transformacaoRN.mostrarTransformacoes();
                case 4 -> {
                    Transformacao tr = new Transformacao();
                    System.out.println("Digite o ID da Transformação para atualizar: ");
                    tr.setId_transformacao(scanner.nextInt());
                    scanner.nextLine();
                    System.out.println("Nome: ");
                    tr.setNome(scanner.nextLine());
                    System.out.println("Nivel: ");
                    tr.setNivel(scanner.nextInt());
                    scanner.nextLine();
                    transformacaoRN.atualizarTransformacao(tr);
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
    
}
