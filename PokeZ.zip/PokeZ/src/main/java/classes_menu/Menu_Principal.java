/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Paulo Henrique
 */
public class Menu_Principal {
    public static void menuPrincipal() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        int opcao = -1;
        
        while (opcao != 0) {
            System.out.println("XXXX BEM VINDO AO POKEZ XXXX");
            System.out.println("1 - Personagem");
            System.out.println("2 - Movimento");
            System.out.println("3 - Status");
            System.out.println("4 - Tecnicas");
            System.out.println("5 - Transformação");
            System.out.println("0 - Sair");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            
            switch (opcao) {
                case 1 -> CRUD_Personagem.executar(scanner);
                case 2 -> CRUD_Movimento.executar(scanner);
                case 3 -> CRUD_Status.executar(scanner);
                case 4 -> CRUD_Tecnicas.executar(scanner);
                case 5 -> CRUD_Transformacao.executar(scanner);
                case 0 -> System.out.println("Encerrando o sistema... ");
                default -> System.out.println("Opção inválida. ");
            }
        }
        scanner.close();
    }
    
}
