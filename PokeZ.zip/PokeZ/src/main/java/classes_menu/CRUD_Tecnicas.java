/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Personagem;
import objetos.Tecnicas;
import regrasNegocio.Tecnicas_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Tecnicas {
    public static void executar(Scanner scanner) throws SQLException {
        Tecnicas_RN tecnicasRN = new Tecnicas_RN();
        int opcao;
        
        do {
            System.out.println("=== TECNICAS ===");
            System.out.println("1 - Cadastrar Tecnica");
            System.out.println("2 - Excluir Tecnica");
            System.out.println("3 - Listar Tecnica");
            System.out.println("4 - Atualizar Tecnica");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    Tecnicas t = new Tecnicas();
                    
                    Personagem p = new Personagem();
                    System.out.println("ID do Personagem: ");
                    p.setId(scanner.nextInt());
                    scanner.nextLine();
                    t.setPersonagem(p);
                    
                    System.out.println("Nome: ");
                    t.setNome(scanner.nextLine());
                    System.out.println("Efeito: ");
                    t.setEfeito(scanner.nextLine());
                    System.out.println("Tipo: ");
                    t.setTipo(scanner.nextLine());
                    scanner.nextLine();
                    tecnicasRN.salvarTecnicas(t);
                }
                case 2 -> {
                    Tecnicas t = new Tecnicas();
                    System.out.println("Digite o ID da Tecnica para excluir: ");
                    t.setId_tecnica(scanner.nextInt());
                    scanner.nextLine();
                    tecnicasRN.deletarTecnicas(t);
                }
                case 3 -> tecnicasRN.mostrarTecnicasS();
                case 4 -> {
                    Tecnicas t = new Tecnicas();
                    System.out.println("Digite o ID da Tecnica para atualizar: ");
                    t.setId_tecnica(scanner.nextInt());
                    scanner.nextLine();
                    System.out.println("Nome: ");
                    t.setNome(scanner.nextLine());
                    System.out.println("Efeito: ");
                    t.setEfeito(scanner.nextLine());
                    System.out.println("Tipo: ");
                    t.setTipo(scanner.nextLine());
                    scanner.nextLine();
                    tecnicasRN.atualizarTecnicas(t);
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
}
