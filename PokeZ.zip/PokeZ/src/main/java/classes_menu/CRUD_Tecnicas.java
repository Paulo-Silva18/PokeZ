/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Personagem;
import objetos.Tecnicas;
import regrasNegocio.Personagem_RN;
import regrasNegocio.Tecnicas_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Tecnicas {
    public static void executar(Scanner scanner) throws SQLException {
        Tecnicas_RN tecnicasRN = new Tecnicas_RN();
        Personagem_RN personagemRN = new Personagem_RN();  
        int opcao;
        
        do {
            System.out.println("=== TECNICAS ===");
            System.out.println("1 - Cadastrar Tecnica");
            System.out.println("2 - Excluir Tecnica");
            System.out.println("3 - Listar Tecnica");
            System.out.println("4 - Atualizar Tecnica");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    System.out.println("Digite o ID do Personagem para associar a Técnica: ");
                    int idPersonagem = scanner.nextInt();
                    scanner.nextLine();

                    Personagem p_encontrado = personagemRN.buscarPersonagemPorId(idPersonagem);
                    
                    if (p_encontrado != null) {
                        Tecnicas t = new Tecnicas();
                        t.setPersonagem(p_encontrado);
                        
                        System.out.println("Nome: ");
                        t.setNome(scanner.nextLine());
                        System.out.println("Efeito: ");
                        t.setEfeito(scanner.nextLine());
                        System.out.println("Tipo: ");
                        t.setTipo(scanner.nextLine());
                        tecnicasRN.salvarTecnicas(t);
                        System.out.println("Técnica cadastrada com sucesso!");
                    } else {
                        System.out.println("ERRO: Personagem com ID " + idPersonagem + " não existe. Impossível cadastrar a técnica.");
                    }
                }
                case 2 -> {
                    System.out.println("Digite o ID da Tecnica para excluir: ");
                    int idParaExcluir = scanner.nextInt();
                    scanner.nextLine();

                    Tecnicas t_encontrada = tecnicasRN.buscarTecnicaPorId(idParaExcluir);
                    
                    if (t_encontrada != null) {
                        tecnicasRN.deletarTecnicas(t_encontrada);
                        System.out.println("Técnica excluída com sucesso!");
                    } else {
                        System.out.println("ERRO: Técnica com ID " + idParaExcluir + " não encontrada.");
                    }
                }
                case 3 -> tecnicasRN.mostrarTecnicasS();
                case 4 -> {
                    System.out.println("Digite o ID da Tecnica para atualizar: ");
                    int idParaAtualizar = scanner.nextInt();
                    scanner.nextLine();

                    Tecnicas t_para_atualizar = tecnicasRN.buscarTecnicaPorId(idParaAtualizar);
                    
                    if (t_para_atualizar != null) {
                        System.out.println("Nome: ");
                        t_para_atualizar.setNome(scanner.nextLine());
                        System.out.println("Efeito: ");
                        t_para_atualizar.setEfeito(scanner.nextLine());
                        System.out.println("Tipo: ");
                        t_para_atualizar.setTipo(scanner.nextLine());
                        tecnicasRN.atualizarTecnicas(t_para_atualizar);
                        System.out.println("Técnica atualizada com sucesso!");
                    } else {
                        System.out.println("ERRO: Técnica com ID " + idParaAtualizar + " não encontrada.");
                    }
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
}
