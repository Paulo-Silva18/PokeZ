/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Movimento;
import objetos.Personagem;
import regrasNegocio.Movimento_RN;
import regrasNegocio.Personagem_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Movimento {
    public static void executar(Scanner scanner) throws SQLException {
        Movimento_RN movimentoRN = new Movimento_RN();
        Personagem_RN personagemRN = new Personagem_RN();
        int opcao;
        
        do {
            System.out.println("=== MOVIMENTO ===");
            System.out.println("1 - Cadastrar Movimento");
            System.out.println("2 - Excluir Movimento");
            System.out.println("3 - Listar Movimento");
            System.out.println("4 - Atualizar Movimento");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    System.out.println("Digite o ID do Personagem para associar o Movimento: ");
                    int idPersonagem = scanner.nextInt();
                    scanner.nextLine();

                    Personagem p_encontrado = personagemRN.buscarPersonagemPorId(idPersonagem);
                    
                    if (p_encontrado != null) {
                        Movimento m = new Movimento();
                        m.setPersonagem(p_encontrado);
                        
                        System.out.println("Nome: ");
                        m.setNome(scanner.nextLine());
                        System.out.println("Dano: ");
                        m.setDano(scanner.nextInt());
                        System.out.println("PP: ");
                        m.setPp(scanner.nextInt());
                        scanner.nextLine();
                        System.out.println("Tipo: ");
                        m.setTipo(scanner.nextLine());
                        movimentoRN.salvarMovimento(m);
                        System.out.println("Movimento cadastrado com sucesso!");
                    } else {
                        System.out.println("ERRO: Personagem com ID " + idPersonagem + " não existe. Impossível cadastrar o movimento.");
                    }
                    
                }
                case 2 -> {
                    System.out.println("Digite o ID do Movimento para excluir: ");
                    int idParaExcluir = scanner.nextInt();
                    scanner.nextLine();
                    
                    Movimento m_encontrado = movimentoRN.buscarMovimentoPorId(idParaExcluir);
                    if (m_encontrado != null) {
                        movimentoRN.deletarMovimento(m_encontrado);
                        System.out.println("Movimento excluído com sucesso!");
                    } else {
                        System.out.println("ERRO: Movimento com ID " + idParaExcluir + " não encontrado.");
                    }
                    
                }
                case 3 -> movimentoRN.mostrarMovimentos();
                case 4 -> {
                    System.out.println("Digite o ID do Movimento para atualizar: ");
                    int idParaAtualizar = scanner.nextInt();
                    scanner.nextLine();

                    Movimento m_para_atualizar = movimentoRN.buscarMovimentoPorId(idParaAtualizar);
                    
                    if(m_para_atualizar != null) {
                        System.out.println("Nome: ");
                        m_para_atualizar.setNome(scanner.nextLine());
                        System.out.println("Dano: ");
                        m_para_atualizar.setDano(scanner.nextInt());
                        System.out.println("PP: ");
                        m_para_atualizar.setPp(scanner.nextInt());
                        scanner.nextLine();
                        System.out.println("Tipo: ");
                        m_para_atualizar.setTipo(scanner.nextLine());
                        movimentoRN.atualizarMovimento(m_para_atualizar);
                        System.out.println("Movimento atualizado com sucesso!");
                    } else {
                        System.out.println("ERRO: Movimento com ID " + idParaAtualizar + " não encontrado.");
                    }
                    
                    
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
}
