/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Movimento;
import objetos.Personagem;
import regrasNegocio.Movimento_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Movimento {
    public static void executar(Scanner scanner) throws SQLException {
        Movimento_RN movimentoRN = new Movimento_RN();
        int opcao;
        
        do {
            System.out.println("=== MOVIMENTO ===");
            System.out.println("1 - Cadastrar Movimento");
            System.out.println("2 - Excluir Movimento");
            System.out.println("3 - Listar Movimento");
            System.out.println("4 - Atualizar Movimento");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    Movimento m = new Movimento();
                    
                    Personagem p = new Personagem();
                    System.out.println("ID do Personagem: ");
                    p.setId(scanner.nextInt());
                    scanner.nextLine();
                    m.setPersonagem(p);
                    
                    System.out.println("Nome: ");
                    m.setNome(scanner.nextLine());
                    System.out.println("Dano: ");
                    m.setDano(scanner.nextInt());
                    System.out.println("PP: ");
                    m.setPp(scanner.nextInt());
                    scanner.nextLine();
                    System.out.println("Tipo: ");
                    m.setTipo(scanner.nextLine());
                    movimentoRN.salvarMovimento(m);
                }
                case 2 -> {
                    Movimento m = new Movimento();
                    System.out.println("Digite o ID do Movimento para excluir: ");
                    m.setId_movimento(scanner.nextInt());
                    scanner.nextLine();
                    movimentoRN.deletarMovimento(m);
                }
                case 3 -> movimentoRN.mostrarMovimentos();
                case 4 -> {
                    Movimento m = new Movimento();
                    System.out.println("Digite o ID do Movimento para atualizar: ");
                    m.setId_movimento(scanner.nextInt());
                    scanner.nextLine();
                    System.out.println("Nome: ");
                    m.setNome(scanner.nextLine());
                    System.out.println("Dano: ");
                    m.setDano(scanner.nextInt());
                    System.out.println("PP: ");
                    m.setPp(scanner.nextInt());
                    System.out.println("Tipo: ");
                    m.setTipo(scanner.nextLine());
                    scanner.nextLine();
                    movimentoRN.atualizarMovimento(m);
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
}
