/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Personagem;
import objetos.Status;
import regrasNegocio.Status_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Status {
    public static void executar(Scanner scanner) throws SQLException {
        Status_RN statusRN = new Status_RN();
        int opcao;
        
        do {
            System.out.println("=== STATUS ===");
            System.out.println("1 - Cadastrar Status");
            System.out.println("2 - Excluir Status");
            System.out.println("3 - Listar Status");
            System.out.println("4 - Atualizar Status");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    Status s = new Status();
                    
                    Personagem p = new Personagem();
                    System.out.println("ID do Personagem: ");
                    p.setId(scanner.nextInt());
                    scanner.nextLine();
                    s.setPersonagem(p);
                    
                    System.out.println("Ataque: ");
                    s.setAtaque(scanner.nextInt());
                    System.out.println("Defesa: ");
                    s.setDefesa(scanner.nextInt());
                    System.out.println("HP: ");
                    s.setHp(scanner.nextInt());
                    System.out.println("Velocidade: ");
                    s.setVelocidade(scanner.nextInt());
                    System.out.println("Speed Ataque: ");
                    s.setSpeed_ataque(scanner.nextInt());
                    System.out.println("Speed Defesa: ");
                    s.setSpeed_defesa(scanner.nextInt());
                    scanner.nextLine();
                    statusRN.salvarStatus(s);
                }
                case 2 -> {
                    Status s = new Status();
                    System.out.println("Digite o ID do Status para excluir: ");
                    s.setId_status(scanner.nextInt());
                    scanner.nextLine();
                    statusRN.deletarStatus(s);
                }
                case 3 -> statusRN.mostrarStatusS();
                case 4 -> {
                    Status s = new Status();
                    System.out.println("Digite o ID do Status para atualizar: ");
                    s.setId_status(scanner.nextInt());
                    scanner.nextLine();
                    System.out.println("Ataque: ");
                    s.setAtaque(scanner.nextInt());
                    System.out.println("Defesa: ");
                    s.setDefesa(scanner.nextInt());
                    System.out.println("HP: ");
                    s.setHp(scanner.nextInt());
                    System.out.println("Velocidade: ");
                    s.setVelocidade(scanner.nextInt());
                    System.out.println("Speed Ataque: ");
                    s.setSpeed_ataque(scanner.nextInt());
                    System.out.println("Speed Defesa: ");
                    s.setSpeed_defesa(scanner.nextInt());
                    scanner.nextLine();
                    statusRN.atualizarStatus(s);
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
}
