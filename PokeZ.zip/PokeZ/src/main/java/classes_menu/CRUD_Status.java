/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Personagem;
import objetos.Status;
import regrasNegocio.Personagem_RN;
import regrasNegocio.Status_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Status {
    public static void executar(Scanner scanner) throws SQLException {
        Status_RN statusRN = new Status_RN();
        Personagem_RN personagemRN = new Personagem_RN();
        int opcao;
        
        do {
            System.out.println("=== STATUS ===");
            System.out.println("1 - Cadastrar Status");
            System.out.println("2 - Excluir Status");
            System.out.println("3 - Listar Status");
            System.out.println("4 - Atualizar Status");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    System.out.println("Digite o ID do Personagem para associar o Status: ");
                    int idPersonagem = scanner.nextInt();
                    scanner.nextLine();

                    Personagem p_encontrado = personagemRN.buscarPersonagemPorId(idPersonagem);

                    if (p_encontrado != null) {
                        Status s = new Status();
                        s.setPersonagem(p_encontrado);
                        System.out.println("Ataque: ");
                        s.setAtaque(scanner.nextInt());
                        System.out.println("Defesa: ");
                        s.setDefesa(scanner.nextInt());
                        System.out.println("HP: ");
                        s.setHp(scanner.nextInt());
                        System.out.println("Velocidade: ");
                        s.setVelocidade(scanner.nextInt());
                        System.out.println("Speed Ataque: ");
                        s.setSpeed_ataque(scanner.nextInt());
                        System.out.println("Speed Defesa: ");
                        s.setSpeed_defesa(scanner.nextInt());
                        scanner.nextLine();
                        statusRN.salvarStatus(s);
                        System.out.println("Status cadastrado com sucesso!");
                    } else {
                        System.out.println("ERRO: Personagem com ID " + idPersonagem + " não existe. Impossível cadastrar o status.");
                    }
                    
                }
                case 2 -> {
                    System.out.println("Digite o ID do Status para excluir: ");
                    int idParaExcluir = scanner.nextInt();
                    scanner.nextLine();

                    Status s_encontrado = statusRN.buscarStatusPorId(idParaExcluir);

                    if (s_encontrado != null) {
                        statusRN.deletarStatus(s_encontrado);
                        System.out.println("Status excluído com sucesso!");
                    } else {
                        System.out.println("ERRO: Status com ID " + idParaExcluir + " não encontrado.");
                    }
                }
                case 3 -> statusRN.mostrarStatusS();
                case 4 -> {
                    System.out.println("Digite o ID do Status para atualizar: ");
                    int idParaAtualizar = scanner.nextInt();
                    scanner.nextLine();

                    Status s_para_atualizar = statusRN.buscarStatusPorId(idParaAtualizar);

                    if (s_para_atualizar != null) {
                        System.out.println("Ataque: ");
                        s_para_atualizar.setAtaque(scanner.nextInt());
                        System.out.println("Defesa: ");
                        s_para_atualizar.setDefesa(scanner.nextInt());
                        System.out.println("HP: ");
                        s_para_atualizar.setHp(scanner.nextInt());
                        System.out.println("Velocidade: ");
                        s_para_atualizar.setVelocidade(scanner.nextInt());
                        System.out.println("Speed Ataque: ");
                        s_para_atualizar.setSpeed_ataque(scanner.nextInt());
                        System.out.println("Speed Defesa: ");
                        s_para_atualizar.setSpeed_defesa(scanner.nextInt());
                        scanner.nextLine();
                        statusRN.atualizarStatus(s_para_atualizar);
                        System.out.println("Status atualizado com sucesso!");
                    } else {
                        System.out.println("ERRO: Status com ID " + idParaAtualizar + " não encontrado.");
                    }
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
}
