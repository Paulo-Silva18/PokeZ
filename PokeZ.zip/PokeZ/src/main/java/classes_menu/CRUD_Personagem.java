/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Personagem;
import regrasNegocio.Personagem_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Personagem {
    public static void executar(Scanner scanner) throws SQLException {
        Personagem_RN personagemRN = new Personagem_RN();
        int opcao;
        
        do {
            System.out.println("=== PERSONAGEM ===");
            System.out.println("1 - Cadastrar Personagem");
            System.out.println("2 - Excluir Personagem");
            System.out.println("3 - Listar Personagem");
            System.out.println("4 - Atualizar Personagem");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    Personagem p = new Personagem();
                    System.out.println("Nome: ");
                    p.setNome(scanner.nextLine());
                    System.out.println("Raça: ");
                    p.setRaca(scanner.nextLine());
                    System.out.println("Altura: ");
                    p.setAltura(scanner.nextDouble());
                    System.out.println("Peso: ");
                    p.setPeso(scanner.nextDouble());
                    scanner.nextLine();
                    personagemRN.salvarPersonagem(p);
                }
                case 2 -> {
                    System.out.println("Digite o ID do Personagem para excluir: ");
                    int idParaExcluir = scanner.nextInt();
                    scanner.nextLine();
                    
                    Personagem p_encontrado = personagemRN.buscarPersonagemPorId(idParaExcluir);

                    if (p_encontrado != null) {
                        personagemRN.deletarPersonagem(p_encontrado);
                        System.out.println("Personagem excluído com sucesso!");
                    } else {
                        System.out.println("ERRO: Personagem com ID " + idParaExcluir + " não encontrado.");
                    }
                }
                case 3 -> personagemRN.mostrarPersonagens();
                case 4 -> {
                    System.out.println("Digite o ID do Personagem para atualizar: ");
                    int idParaAtualizar = scanner.nextInt();
                    scanner.nextLine();

                    Personagem p_para_atualizar = personagemRN.buscarPersonagemPorId(idParaAtualizar);

                    if (p_para_atualizar != null) {
                        System.out.println("Nome: ");
                        p_para_atualizar.setNome(scanner.nextLine());
                        System.out.println("Raça: ");
                        p_para_atualizar.setRaca(scanner.nextLine());
                        System.out.println("Altura: ");
                        p_para_atualizar.setAltura(scanner.nextDouble());
                        System.out.println("Peso: ");
                        p_para_atualizar.setPeso(scanner.nextDouble());
                        scanner.nextLine();
                        personagemRN.atualizarPersonagem(p_para_atualizar);
                        System.out.println("Personagem atualizado com sucesso!");
                    } else {
                        System.out.println("ERRO: Personagem com ID " + idParaAtualizar + " não encontrado.");
                    }
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
}
