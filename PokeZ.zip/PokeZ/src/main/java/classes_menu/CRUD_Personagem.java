/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.sql.SQLException;
import java.util.Scanner;
import objetos.Personagem;
import regrasNegocio.Personagem_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Personagem {
    public static void executar(Scanner scanner) throws SQLException {
        Personagem_RN personagemRN = new Personagem_RN();
        int opcao;
        
        do {
            System.out.println("=== PERSONAGEM ===");
            System.out.println("1 - Cadastrar Personagem");
            System.out.println("2 - Excluir Personagem");
            System.out.println("3 - Listar Personagem");
            System.out.println("4 - Atualizar Personagem");
            System.out.println("0 - Voltar");
            System.out.println("Qual opção deseja escolher? ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    Personagem p = new Personagem();
                    System.out.println("Nome: ");
                    p.setNome(scanner.nextLine());
                    System.out.println("Raça: ");
                    p.setRaca(scanner.nextLine());
                    System.out.println("Altura: ");
                    p.setAltura(scanner.nextDouble());
                    System.out.println("Peso: ");
                    p.setPeso(scanner.nextDouble());
                    scanner.nextLine();
                    personagemRN.salvarPersonagem(p);
                }
                case 2 -> {
                    Personagem p = new Personagem();
                    System.out.println("Digite o ID do Personagem para excluir: ");
                    p.setId(scanner.nextInt());
                    scanner.nextLine();
                    personagemRN.deletarPersonagem(p);
                }
                case 3 -> personagemRN.mostrarPersonagens();
                case 4 -> {
                    Personagem p = new Personagem();
                    System.out.println("Digite o ID do Personagem para atualizar: ");
                    p.setId(scanner.nextInt());
                    scanner.nextLine();
                    System.out.println("Nome: ");
                    p.setNome(scanner.nextLine());
                    System.out.println("Raça: ");
                    p.setRaca(scanner.nextLine());
                    System.out.println("Altura: ");
                    p.setAltura(scanner.nextDouble());
                    System.out.println("Peso: ");
                    p.setPeso(scanner.nextDouble());
                    scanner.nextLine();
                    personagemRN.atualizarPersonagem(p);
                }
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
}
