/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import objetos.Movimento;
import objetos.Personagem;
import objetos.Status;
import objetos.Tecnicas;
import objetos.Transformacao;
import util.Conexao;

/**
 *
 * @author Paulo Henrique
 */
public class Personagem_BD {
    Connection conn;
    Movimento_BD m_BD;
    Status_BD s_BD;
    Tecnicas_BD t_BD;
    Transformacao_BD tr_BD;
    
    public Personagem_BD() {
        conn = new Conexao().conectar();
        this.m_BD = new Movimento_BD();
        this.s_BD = new Status_BD();
        this.t_BD = new Tecnicas_BD();
        this.tr_BD = new Transformacao_BD();
    }
    
    public Personagem salvar(Personagem p) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO Personagem(nome, raca, altura, peso) values(?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getRaca());
            stmt.setDouble(3, p.getAltura());
            stmt.setDouble(4, p.getPeso());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return p;
    }
    
    public Personagem deletar(Personagem p) {
        if (p.getId() <= 0) {
            System.err.println("Personagem não existe");
        }

        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM Personagem WHERE id = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, p.getId());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return p;
    }
    
    public Personagem atualizar(Personagem p) {
        if (p.getId() <= 0) {
            System.err.println("ID Personagem não existe");
        }
        try {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Personagem SET nome = ?, raca = ?, altura = ?, peso = ? WHERE id = ?", Statement.RETURN_GENERATED_KEYS);
            
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getRaca());
            stmt.setDouble(3, p.getAltura());
            stmt.setDouble(4, p.getPeso());
            stmt.setInt(5, p.getId());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return p;
    }
    
    public List<Personagem> getPersonagens_All() {
        List<Personagem> lstP = new ArrayList<>();
        List<Movimento> lstM = new ArrayList<>();
        List<Status> lstS = new ArrayList<>();
        List<Tecnicas> lstT = new ArrayList<>();
        List<Transformacao> lstTR = new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM Personagem JOIN Movimento ON Personagem.id = Movimento.idpersonagem JOIN Status ON Status.idpersonagem = Personagem.id JOIN Tecnicas ON Tecnicas.idpersonagem = Personagem.id JOIN Transformacao ON Transformacao.idpersonagem = Personagem.id;");
            rs = ppStmt.executeQuery();
            int verif_id = 0;
            while(rs.next()) {
                if (rs.getInt("idmovimento") == 0 || rs.getInt("idstatus") == 0 || rs.getInt("idtecnica") == 0 || rs.getInt("idtransformacao") == 0) {
                    lstP.add(getPersonagem(rs));
                }
                else {
                    Personagem p = getPersonagem(rs);
                    if (verif_id == p.getId()) {
                        lstM.add(m_BD.getMovimento(rs));
                        lstS.add(s_BD.getStatus(rs));
                        lstT.add(t_BD.getTecnicas(rs));
                        lstTR.add(tr_BD.getTransformacao(rs));
                        p = lstP.getLast();
                        p.setMovimentos(lstM);
                        p.setStatus(lstS);
                        p.setTecnicas(lstT);
                        p.setTransformacoes(lstTR);
                    }
                    else {
                        lstM.add(m_BD.getMovimento(rs));
                        lstS.add(s_BD.getStatus(rs));
                        lstT.add(t_BD.getTecnicas(rs));
                        lstTR.add(tr_BD.getTransformacao(rs));
                        p.setMovimentos(lstM);
                        p.setStatus(lstS);
                        p.setTecnicas(lstT);
                        p.setTransformacoes(lstTR);
                        lstP.add(p);
                        verif_id = p.getId();
                    }
                }
                
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public List<Personagem> getPersonagens() throws SQLException {
        List<Personagem> lstP = new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM Personagem");
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstP.add(getPersonagem(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstP;
    }
    
    
    
    private Personagem getPersonagem(ResultSet rs) throws SQLException {
        Personagem p = new Personagem();
        
        p.setId(rs.getInt("id"));
        p.setNome(rs.getString("nome"));
        p.setRaca(rs.getString("raca"));
        p.setAltura(rs.getDouble("altura"));
        p.setPeso(rs.getDouble("peso"));
        return p;
    }
}
