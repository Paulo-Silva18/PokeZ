/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import objetos.Personagem;
import objetos.Status;
import util.Conexao;

/**
 *
 * @author Paulo Henrique
 */
public class Status_BD {
    Connection conn;
    
    public Status_BD() {
        conn = new Conexao().conectar();
    }
    
    public Status salvar(Status s) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO Status(ataque, defesa, hp, velocidade, speed_ataque, speed_defesa, idpersonagem) values(?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, s.getAtaque());
            stmt.setInt(2, s.getDefesa());
            stmt.setInt(3, s.getHp());
            stmt.setInt(4, s.getVelocidade());
            stmt.setInt(5, s.getSpeed_ataque());
            stmt.setInt(6, s.getSpeed_defesa());
            stmt.setInt(7, s.getPersonagem().getId());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return s;
    }
    
    public Status deletar(Status s) {
        if (s.getId_status()<= 0) {
            System.err.println("ID Status não existe");
        }
        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM Status WHERE idstatus = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, s.getId_status());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return s;
    }
    
    public Status atualizar(Status s) {
        if (s.getId_status()<= 0) {
            System.err.println("ID Status não existe");
        }
        try {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Status SET ataque = ?, defesa = ?, hp = ?, velocidade = ?, speed_ataque = ?, speed_defesa = ? WHERE idstatus = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, s.getAtaque());
            stmt.setInt(2, s.getDefesa());
            stmt.setInt(3, s.getHp());
            stmt.setInt(4, s.getVelocidade());
            stmt.setInt(5, s.getSpeed_ataque());
            stmt.setInt(6, s.getSpeed_defesa());
            stmt.setInt(7, s.getId_status());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return s;
    }
    
    public List<Status> getStatusS() {
        List<Status> lstS= new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM Status");
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstS.add(getStatus(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstS;
        }
    
    public Status getStatus(ResultSet rs) throws SQLException {
        Status s = new Status();
        Personagem p = new Personagem();
        
        s.setId_status(rs.getInt("idstatus"));
        s.setAtaque(rs.getInt("ataque"));
        s.setDefesa(rs.getInt("defesa"));
        s.setHp(rs.getInt("hp"));
        s.setVelocidade(rs.getInt("velocidade"));
        s.setSpeed_ataque(rs.getInt("speed_ataque"));
        s.setSpeed_defesa(rs.getInt("speed_defesa"));
        p.setId(rs.getInt("id"));
        s.setPersonagem(p);
        return s;
    }
}
