/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import objetos.Personagem;
import objetos.Tecnicas;
import util.Conexao;

/**
 *
 * @author Paulo Henrique
 */
public class Tecnicas_BD {
    Connection conn;
    
    public Tecnicas_BD() {
        conn = new Conexao().conectar();
    }
    
    public Tecnicas salvar(Tecnicas t) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO Tecnicas(nome, efeito, tipo, idpersonagem) values(?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, t.getNome());
            stmt.setString(2, t.getEfeito());
            stmt.setString(3, t.getTipo());
            stmt.setInt(4, t.getPersonagem().getId());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return t;
    }
    
    public Tecnicas deletar(Tecnicas t) {
        if (t.getId_tecnica()<= 0) {
            System.err.println("ID Tecnica não existe");
        }
        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM Tecnicas WHERE idtecnica = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, t.getId_tecnica());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return t;
    }
    
    public Tecnicas atualizar(Tecnicas t) {
        if (t.getId_tecnica()<= 0) {
            System.err.println("ID Tecnica não existe");
        }
        try {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Tecnicas SET nome = ?, efeito = ?, tipo = ? WHERE idtecnica = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, t.getNome());
            stmt.setString(2, t.getEfeito());
            stmt.setString(3, t.getTipo());
            stmt.setInt(4, t.getId_tecnica());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return t;
    }
    
    public List<Tecnicas> getTecnicasS() {
        List<Tecnicas> lstT = new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM Tecnicas");
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstT.add(getTecnicas(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstT;
    }
    
    public Tecnicas buscarPorId(int id) {
        String sql = "SELECT * FROM Tecnicas WHERE idtecnica = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return getTecnicas(rs);
            }
            stmt.close();
            rs.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public Tecnicas getTecnicas(ResultSet rs) throws SQLException {
        Tecnicas t = new Tecnicas();
        Personagem p = new Personagem();
        
        t.setId_tecnica(rs.getInt("idtecnica"));
        t.setNome(rs.getString("nome"));
        t.setEfeito(rs.getString("efeito"));
        t.setTipo(rs.getString("tipo"));
        p.setId(rs.getInt("idpersonagem"));
        t.setPersonagem(p);
        return t;
    }
}
