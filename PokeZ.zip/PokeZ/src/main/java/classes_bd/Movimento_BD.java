/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import objetos.Movimento;
import objetos.Personagem;
import util.Conexao;

/**
 *
 * @author Paulo Henrique
 */
public class Movimento_BD {
    Connection conn;
    
    public Movimento_BD() {
        conn = new Conexao().conectar();
    }
    
    public Movimento salvar(Movimento m) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO Movimento(nome, dano, pp, tipo, idpersonagem) values(?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, m.getNome());
            stmt.setInt(2, m.getDano());
            stmt.setInt(3, m.getPp());
            stmt.setString(4, m.getTipo());
            stmt.setInt(5, m.getPersonagem().getId());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return m;
    }
    
    public Movimento deletar(Movimento m) {
        if (m.getId_movimento()<= 0) {
            System.err.println("ID Movimento não existe");
        }
        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM Movimento WHERE idmovimento = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, m.getId_movimento());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return m;
    }
    
    public Movimento atualizar(Movimento m) {
        if (m.getId_movimento()<= 0) {
            System.err.println("ID Movimento não existe");
        }
        try {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Movimento SET nome = ?, dano = ?, pp = ?, tipo = ? WHERE idmovimento = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, m.getNome());
            stmt.setInt(2, m.getDano());
            stmt.setInt(3, m.getPp());
            stmt.setString(4, m.getTipo());
            stmt.setInt(5, m.getId_movimento());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return m;
    }
    
    public List<Movimento> getMovimentos() {
        List<Movimento> lstM = new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM Movimento");
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstM.add(getMovimento(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstM;
        }
    
    public Movimento getMovimento(ResultSet rs) throws SQLException {
        Movimento m = new Movimento();
        Personagem p = new Personagem();
        
        m.setId_movimento(rs.getInt("idmovimento"));
        m.setNome(rs.getString("nome"));
        m.setDano(rs.getInt("dano"));
        m.setPp(rs.getInt("pp"));
        m.setTipo(rs.getString("tipo"));
        p.setId(rs.getInt("idpersonagem"));
        m.setPersonagem(p);
        return m;
    }
}
