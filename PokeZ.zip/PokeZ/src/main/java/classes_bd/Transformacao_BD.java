/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import objetos.Personagem;
import objetos.Transformacao;
import util.Conexao;

/**
 *
 * @author Paulo Henrique
 */
public class Transformacao_BD {
    Connection conn;
    
    public Transformacao_BD() {
        conn = new Conexao().conectar();
    }
    
    public Transformacao salvar(Transformacao tr) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO Transformacao(nome, nivel, idpersonagem) values(?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, tr.getNome());
            stmt.setInt(2, tr.getNivel());
            stmt.setInt(3, tr.getPersonagem().getId());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return tr;
    }
    
    public Transformacao deletar(Transformacao tr) {
        if (tr.getId_transformacao()<= 0) {
            System.err.println("ID Transformacao não existe");
        }
        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM Transformacao WHERE idtransformacao = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, tr.getId_transformacao());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return tr;
    }
    
    public Transformacao atualizar(Transformacao tr) {
        if (tr.getId_transformacao()<= 0) {
            System.err.println("ID Transformacao não existe");
        }
        try {
            PreparedStatement stmt = conn.prepareStatement("UPDATE Transformacao SET nome = ?, nivel = ? WHERE idtransformacao = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, tr.getNome());
            stmt.setInt(2, tr.getNivel());
            stmt.setInt(3, tr.getId_transformacao());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return tr;
    }
    
    public List<Transformacao> getTransformacoes() {
        List<Transformacao> lstTR = new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM Transformacao");
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstTR.add(getTransformacao(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstTR;
    }
    
    public Transformacao buscarPorId(int id) {
        String sql = "SELECT * FROM Transformacao WHERE idtransformacao = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return getTransformacao(rs);
            }
            stmt.close();
            rs.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public Transformacao getTransformacao(ResultSet rs) throws SQLException {
        Transformacao tr = new Transformacao();
        Personagem p = new Personagem();
        
        tr.setId_transformacao(rs.getInt("idtransformacao"));
        tr.setNome(rs.getString("nome"));
        tr.setNivel(rs.getInt("nivel"));
        p.setId(rs.getInt("idpersonagem"));
        tr.setPersonagem(p);
        return tr;
    }
}
